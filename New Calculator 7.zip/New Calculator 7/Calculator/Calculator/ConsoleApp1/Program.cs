﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibrary;
using MathLibray;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine( ExpressionEvaluation.PostFixEvaluation("2+2"));
            Console.WriteLine(Class1.CalculateS("2+2"));
        }
    }
}
